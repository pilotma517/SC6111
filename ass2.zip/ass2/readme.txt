templates中存的是前端网页，app.py是后端代码，datasql是sql命令
这是一个使用 Flask 框架构建的简单用户系统，主要功能包括：
注册：新用户可以创建账户，注册信息将安全地存储在 MariaDB 数据库中，密码经过哈希处理。
登录：已注册用户可以使用用户名和密码登录系统，登录状态通过 Flask Session 进行管理。
仪表板：登录成功的用户可以访问仪表板页面，查看个性化内容。
注销：用户可以安全地退出登录，清除会话信息。
The templates store the front-end web pages, app.cy is the back-end code, and datasql is the SQL command
This is a simple user system built using the Flask framework, with main features including:
Registration: New users can create accounts, and registration information will be securely stored in the MariaDB database. Passwords will be hashed.
Login: Registered users can log in to the system using their username and password, and their login status is managed through Flask Session.
Dashboard: Users who have successfully logged in can access the dashboard page to view personalized content.
Logout: Users can safely log out and clear session information.