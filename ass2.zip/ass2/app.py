import os
import mariadb
from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize the Flask application
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Database connection function
def get_db():
    # Configure the database connection
    return mariadb.connect(
        user='root',          # MariaDB username
        password='123456',    # MariaDB password
        host='127.0.0.1',     # Database host address
        port=3306,            # Database port number
        database='USER_SYSTEM'  # Database name
    )

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# User registration route
@app.route('/register', methods=['POST'])
def register_user():
    user = request.form.get('username')
    pwd = request.form.get('password')
    hashed_pwd = generate_password_hash(pwd)

    conn = get_db()
    cursor = conn.cursor()

    try:
        # Insert new user data
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (%s, %s)",
            (user, hashed_pwd)
        )
        conn.commit()
        return redirect(url_for('home'))
    except mariadb.IntegrityError:
        # Username already exists
        return "User already exists.", 400
    finally:
        # Close the database connection
        cursor.close()
        conn.close()

# User login route
@app.route('/login', methods=['POST'])
def login_user():
    user = request.form.get('username')
    pwd = request.form.get('password')

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, password_hash FROM users WHERE username = %s", (user,)
    )
    user_record = cursor.fetchone()

    if user_record and check_password_hash(user_record[1], pwd):
        # Login successful, set session
        session['user_id'] = user_record[0]
        session.permanent = True if 'remember_me' in request.form else False
        return redirect(url_for('dashboard'))
    else:
        # Login failed
        return "Invalid username or password.", 400

# User dashboard route
@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        # User is logged in, display dashboard
        return render_template('dashboard.html')
    else:
        # User is not logged in, redirect to home
        return redirect(url_for('home'))

# User logout route
@app.route('/logout', methods=['POST'])
def logout_user():
    # Clear the user ID from the session
    session.pop('user_id', None)
    return redirect(url_for('home'))

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
